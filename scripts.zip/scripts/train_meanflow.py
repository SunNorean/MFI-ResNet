
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
import torchvision.transforms as transforms
from torch.optim.lr_scheduler import CosineAnnealingLR
from tqdm import tqdm
import os
import argparse
from datetime import datetime

class LabelSmoothingCrossEntropy(nn.Module):

    def __init__(self, smoothing=0.1):
        super().__init__()
        self.smoothing = smoothing

    def forward(self, pred, target):
        n_classes = pred.size(1)

        one_hot = F.one_hot(target, n_classes).float()
        smoothed = one_hot * (1 - self.smoothing) + self.smoothing / n_classes

        log_probs = F.log_softmax(pred, dim=1)
        loss = -(smoothed * log_probs).sum(dim=1).mean()

        return loss

class DimAlignModule(nn.Module):

    def __init__(self, in_channels, out_channels, target_size):
        super().__init__()
        self.target_size = target_size
        self.out_channels = out_channels

        self.align_conv = nn.Conv2d(in_channels, out_channels, kernel_size=3,
                                     stride=1, padding=1, bias=False)
        self.bn = nn.BatchNorm2d(out_channels)

    def forward(self, x):
        x_align = self.align_conv(x)
        x_align = self.bn(x_align)
        x_align = F.relu(x_align)
        return x_align

class MeanFlowModule(nn.Module):

    def __init__(self, dim_align_module):
        super().__init__()
        self.dim_align = dim_align_module
        self.out_dim = dim_align_module.out_channels
        self.target_spatial_size = dim_align_module.target_size

        if self.out_dim == 256:
            time_emb_dim = 32
            hidden_dim = 384
        elif self.out_dim == 512:
            time_emb_dim = 32
            hidden_dim = 512
        elif self.out_dim <= 1024:
            time_emb_dim = 64
            hidden_dim = 1024
        else:
            time_emb_dim = 64
            hidden_dim = 1024

        self.time_emb = nn.Linear(2, time_emb_dim)
        self.u_net = nn.Sequential(
            nn.Linear(self.out_dim + time_emb_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, self.out_dim)
        )

    def forward_u(self, z, r, t):

        rt = torch.cat([r.unsqueeze(1), t.unsqueeze(1)], dim=1)
        rt_emb = self.time_emb(rt)
        z_rt = torch.cat([z, rt_emb], dim=1)
        return self.u_net(z_rt)

    def forward(self, x):

        B = x.shape[0]
        device = x.device

        x_align = self.dim_align(x)

        r = torch.zeros(B, device=device)
        t = torch.ones(B, device=device)

        spatial_flatten_size = self.target_spatial_size[0] * self.target_spatial_size[1]
        z_align = x_align.permute(0, 2, 3, 1).reshape(B * spatial_flatten_size, self.out_dim)
        r_flat = r.repeat_interleave(spatial_flatten_size)
        t_flat = t.repeat_interleave(spatial_flatten_size)

        u_pred = self.forward_u(z_align, r_flat, t_flat)
        z_mapped = z_align - u_pred

        feat_mapped = z_mapped.reshape(B, self.target_spatial_size[0],
                                       self.target_spatial_size[1], self.out_dim)
        feat_mapped = feat_mapped.permute(0, 3, 1, 2)

        return feat_mapped

class MeanFlowStage(nn.Module):

    def __init__(self, in_channels, out_channels, target_size, downsample=False, use_learnable_downsample=True):
        super().__init__()
        self.downsample = downsample
        self.use_learnable_downsample = use_learnable_downsample

        dim_align = DimAlignModule(in_channels, out_channels, target_size)
        self.meanflow = MeanFlowModule(dim_align)

        if downsample:
            if use_learnable_downsample:

                self.downsample_layer = nn.Conv2d(out_channels, out_channels,
                                                 kernel_size=3, stride=2, padding=1, bias=False)
                self.downsample_bn = nn.BatchNorm2d(out_channels)
            else:

                self.downsample_layer = nn.AvgPool2d(kernel_size=2, stride=2)

    def forward(self, x):
        x = self.meanflow(x)
        if self.downsample:
            x = self.downsample_layer(x)
            if self.use_learnable_downsample and hasattr(self, 'downsample_bn'):
                x = self.downsample_bn(x)
        return x

class FourStageMeanFlowPipeline(nn.Module):

    def __init__(self, num_classes=10, use_fixed_downsample=True, arch='resnet50'):
        super().__init__()

        if arch.lower() == 'resnet50':

            channels = [64, 256, 512, 1024, 2048]
        else:

            channels = [64, 64, 128, 256, 512]

        self.arch = arch

        self.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(64)

        self.stage1 = MeanFlowStage(channels[0], channels[1], target_size=(32, 32), downsample=False)
        self.stage2 = MeanFlowStage(channels[1], channels[2], target_size=(32, 32), downsample=True,
                                     use_learnable_downsample=not use_fixed_downsample)
        self.stage3 = MeanFlowStage(channels[2], channels[3], target_size=(16, 16), downsample=True,
                                     use_learnable_downsample=not use_fixed_downsample)
        self.stage4 = MeanFlowStage(channels[3], channels[4], target_size=(8, 8), downsample=True,
                                     use_learnable_downsample=not use_fixed_downsample)

        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.linear = nn.Linear(channels[4], num_classes)

    def forward(self, x):

        x = self.conv1(x)
        x = self.bn1(x)
        x = F.relu(x)

        x = self.stage1(x)
        x = self.stage2(x)
        x = self.stage3(x)
        x = self.stage4(x)

        x = self.avgpool(x)
        x = x.view(x.size(0), -1)
        x = self.linear(x)

        return x

def train_one_epoch(model, train_loader, criterion, optimizer, device, epoch, total_epochs):

    model.train()
    running_loss = 0.0
    correct = 0
    total = 0

    pbar = tqdm(train_loader, desc=f'Epoch {epoch+1}/{total_epochs} [Train]')
    for inputs, targets in pbar:
        inputs, targets = inputs.to(device), targets.to(device)

        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, targets)
        loss.backward()
        optimizer.step()

        running_loss += loss.item()
        _, predicted = outputs.max(1)
        total += targets.size(0)
        correct += predicted.eq(targets).sum().item()

        pbar.set_postfix({
            'loss': f'{running_loss / (pbar.n + 1):.4f}',
            'acc': f'{100. * correct / total:.2f}%',
            'lr': f'{optimizer.param_groups[0]["lr"]:.6f}'
        })

    epoch_loss = running_loss / len(train_loader)
    epoch_acc = 100. * correct / total

    return epoch_loss, epoch_acc

def evaluate(model, test_loader, criterion, device):

    model.eval()
    running_loss = 0.0
    correct = 0
    total = 0

    with torch.no_grad():
        pbar = tqdm(test_loader, desc='[Eval]')
        for inputs, targets in pbar:
            inputs, targets = inputs.to(device), targets.to(device)

            outputs = model(inputs)
            loss = criterion(outputs, targets)

            running_loss += loss.item()
            _, predicted = outputs.max(1)
            total += targets.size(0)
            correct += predicted.eq(targets).sum().item()

            pbar.set_postfix({
                'loss': f'{running_loss / (pbar.n + 1):.4f}',
                'acc': f'{100. * correct / total:.2f}%'
            })

    test_loss = running_loss / len(test_loader)
    test_acc = 100. * correct / total

    return test_loss, test_acc

def get_cifar10_loaders(batch_size=128, num_workers=4):

    pass

    transform_train = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616))
    ])

    transform_test = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616))
    ])

    trainset = torchvision.datasets.CIFAR10(
        root='./data', train=True, download=True, transform=transform_train
    )
    train_loader = torch.utils.data.DataLoader(
        trainset, batch_size=batch_size, shuffle=True,
        num_workers=num_workers, pin_memory=True
    )

    testset = torchvision.datasets.CIFAR10(
        root='./data', train=False, download=True, transform=transform_test
    )
    test_loader = torch.utils.data.DataLoader(
        testset, batch_size=batch_size, shuffle=False,
        num_workers=num_workers, pin_memory=True
    )

    pass
    pass

    return train_loader, test_loader

def main():
    parser = argparse.ArgumentParser(

    )

    parser.add_argument('--pretrained-model', type=str,
                        default='./merged_meanflow_res50/merged_meanflow_4stages_pipeline.pth',
)
    parser.add_argument('--load-pretrained', action='store_true', default=True,
)

    parser.add_argument('--epochs', type=int, default=300,
)
    parser.add_argument('--batch-size', type=int, default=64,
)

    parser.add_argument('--optimizer', type=str, default='adamw',
                        choices=['adamw', 'sgd'],
)
    parser.add_argument('--lr', type=float, default=0.001,
)
    parser.add_argument('--min-lr', type=float, default=1e-6,
)
    parser.add_argument('--momentum', type=float, default=0.9,
)
    parser.add_argument('--weight-decay', type=float, default=None,
)

    parser.add_argument('--use-label-smoothing', action='store_true', default=True,
)
    parser.add_argument('--label-smoothing', type=float, default=0.1,
)

    parser.add_argument('--save-dir', type=str, default='./checkpoints_meanflow_trained',
)
    parser.add_argument('--num-workers', type=int, default=4,
)
    parser.add_argument('--device', type=str, default='cuda',
)
    parser.add_argument('--save-interval', type=int, default=10,
)

    args = parser.parse_args()

    if args.lr is None:
        if args.optimizer == 'adamw':
            args.lr = 0.001
        else:
            args.lr = 0.05
        pass

    if args.weight_decay is None:
        if args.optimizer == 'adamw':
            args.weight_decay = 0.01
        else:
            args.weight_decay = 5e-4
        pass

    os.makedirs(args.save_dir, exist_ok=True)

    pass
    pass
    pass
    pass

    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass

    device = torch.device(args.device if torch.cuda.is_available() else 'cpu')
    pass

    pass
    pass
    pass

    model = FourStageMeanFlowPipeline(num_classes=10, use_fixed_downsample=True)

    if args.load_pretrained and os.path.exists(args.pretrained_model):
        pass
        checkpoint = torch.load(args.pretrained_model, map_location='cpu')

        if 'model_state_dict' in checkpoint:
            state_dict = checkpoint['model_state_dict']
        else:
            state_dict = checkpoint

        missing_keys, unexpected_keys = model.load_state_dict(state_dict, strict=False)

        pass
        if missing_keys:
            pass
        if unexpected_keys:
            pass

        if 'note' in checkpoint:
            pass
    else:
        pass

    model = model.to(device)

    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    pass
    pass
    pass
    pass

    train_loader, test_loader = get_cifar10_loaders(
        batch_size=args.batch_size,
        num_workers=args.num_workers
    )

    if args.use_label_smoothing:
        criterion = LabelSmoothingCrossEntropy(smoothing=args.label_smoothing)
        pass
    else:
        criterion = nn.CrossEntropyLoss()
        pass

    if args.optimizer == 'adamw':
        optimizer = torch.optim.AdamW(
            model.parameters(),
            lr=args.lr,
            weight_decay=args.weight_decay,
            betas=(0.9, 0.999)
        )
        pass
    else:
        optimizer = torch.optim.SGD(
            model.parameters(),
            lr=args.lr,
            momentum=args.momentum,
            weight_decay=args.weight_decay
        )
        pass

    scheduler = CosineAnnealingLR(
        optimizer,
        T_max=args.epochs,
        eta_min=args.min_lr
    )
    pass

    pass
    pass
    pass

    best_acc = 0.0

    for epoch in range(args.epochs):

        train_loss, train_acc = train_one_epoch(
            model, train_loader, criterion, optimizer, device,
            epoch, args.epochs
        )

        test_loss, test_acc = evaluate(model, test_loader, criterion, device)

        scheduler.step()
        current_lr = optimizer.param_groups[0]['lr']

        pass
        pass
        pass
        pass

        if test_acc > best_acc:
            best_acc = test_acc

            save_dict = {
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
                'best_accuracy': best_acc,
                'train_accuracy': train_acc,
                'architecture': 'FourStageMeanFlowPipeline',
                'optimizer': args.optimizer,
                'use_label_smoothing': args.use_label_smoothing,
                'args': vars(args)
            }

            torch.save(save_dict, os.path.join(args.save_dir, 'best_meanflow_pipeline_trained_res50.pth'))
            pass

        if (epoch + 1) % args.save_interval == 0:
            checkpoint_path = os.path.join(args.save_dir, f'checkpoint_epoch_{epoch+1}.pth')
            save_dict = {
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
                'test_accuracy': test_acc,
                'train_accuracy': train_acc,
            }
            torch.save(save_dict, checkpoint_path)
            pass

        pass

    pass
    pass
    pass
    pass

    pass
    pass
    pass
    pass
    pass
    pass

    if best_acc >= 94.0:
        pass
        pass
    elif best_acc >= 92.0:
        pass
        pass
    else:
        pass
        pass
        pass
        pass
    pass

if __name__ == '__main__':
    main()
