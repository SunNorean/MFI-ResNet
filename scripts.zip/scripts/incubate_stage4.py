
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader
import torchvision
import torchvision.transforms as transforms
import argparse
import os
from tqdm import tqdm
import sys

class DimAlignModule(nn.Module):

    def __init__(self, in_channels, out_channels, target_size):
        super().__init__()
        self.target_size = target_size
        self.out_channels = out_channels

        self.align_conv = nn.Conv2d(in_channels, out_channels, kernel_size=3,
                                     stride=1, padding=1, bias=False)
        self.bn = nn.BatchNorm2d(out_channels)

    def forward(self, x):
        x_align = self.align_conv(x)
        x_align = self.bn(x_align)
        x_align = F.relu(x_align)
        return x_align

class MeanFlowModule(nn.Module):

    def __init__(self, dim_align_module):
        super().__init__()
        self.dim_align = dim_align_module
        self.out_dim = dim_align_module.out_channels
        self.target_spatial_size = dim_align_module.target_size

        self.time_emb = nn.Linear(2, 32)
        self.u_net = nn.Sequential(
            nn.Linear(self.out_dim + 32, 256),
            nn.ReLU(),
            nn.Linear(256, 256),
            nn.ReLU(),
            nn.Linear(256, self.out_dim)
        )

    def forward_u(self, z, r, t):

        rt = torch.cat([r.unsqueeze(1), t.unsqueeze(1)], dim=1)
        rt_emb = self.time_emb(rt)
        z_rt = torch.cat([z, rt_emb], dim=1)
        return self.u_net(z_rt)

    def forward(self, x):

        B = x.shape[0]
        device = x.device

        x_align = self.dim_align(x)

        r = torch.zeros(B, device=device)
        t = torch.ones(B, device=device)

        spatial_flatten_size = self.target_spatial_size[0] * self.target_spatial_size[1]
        z_align = x_align.permute(0, 2, 3, 1).reshape(B * spatial_flatten_size, self.out_dim)
        r_flat = r.repeat_interleave(spatial_flatten_size)
        t_flat = t.repeat_interleave(spatial_flatten_size)

        u_pred = self.forward_u(z_align, r_flat, t_flat)
        z_mapped = z_align - u_pred

        feat_mapped = z_mapped.reshape(B, self.target_spatial_size[0],
                                       self.target_spatial_size[1], self.out_dim)
        feat_mapped = feat_mapped.permute(0, 3, 1, 2)

        return feat_mapped

class MeanFlowStage(nn.Module):

    def __init__(self, in_channels, out_channels, target_size, downsample=False, use_learnable_downsample=True):
        super().__init__()
        self.downsample = downsample
        self.use_learnable_downsample = use_learnable_downsample

        dim_align = DimAlignModule(in_channels, out_channels, target_size)
        self.meanflow = MeanFlowModule(dim_align)

        if downsample:
            if use_learnable_downsample:
                self.downsample_layer = nn.Conv2d(out_channels, out_channels,
                                                 kernel_size=1, stride=2, padding=0, bias=False)
                self.downsample_bn = nn.BatchNorm2d(out_channels)
            else:
                self.downsample_layer = nn.AvgPool2d(kernel_size=2, stride=2)

    def forward(self, x):
        x = self.meanflow(x)
        if self.downsample:
            x = self.downsample_layer(x)
            if self.use_learnable_downsample and hasattr(self, 'downsample_bn'):
                x = self.downsample_bn(x)
        return x

class _TwoStepStage4Internal(nn.Module):

    def __init__(self, in_channels=1024, out_channels=2048):
        super().__init__()
        mid_channels = (in_channels + out_channels) // 2

        self.dim_align_step1 = nn.Sequential(
            nn.Conv2d(in_channels, mid_channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(mid_channels),
            nn.ReLU()
        )

        self.meanflow_step1 = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(mid_channels, 256),
            nn.ReLU(),
            nn.Linear(256, mid_channels)
        )

        self.dim_align_step2 = nn.Sequential(
            nn.Conv2d(mid_channels, out_channels, kernel_size=1, stride=2, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU()
        )

        self.meanflow_step2 = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(out_channels, 256),
            nn.ReLU(),
            nn.Linear(256, out_channels)
        )

    def forward(self, x):

        x = self.dim_align_step1(x)
        B, C, H, W = x.shape
        delta1 = self.meanflow_step1(x).view(B, C, 1, 1)
        x = x - delta1

        x = self.dim_align_step2(x)
        B, C, H, W = x.shape
        delta2 = self.meanflow_step2(x).view(B, C, 1, 1)
        x = x - delta2

        return x

class FourStageMeanFlowPipeline(nn.Module):

    def __init__(self, num_classes=10, use_fixed_downsample=True):
        super().__init__()

        channels = [64, 256, 512, 1024, 2048]
        self.arch = 'resnet50'

        pass
        pass

        self.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(64)

        self.stage1 = MeanFlowStage(channels[0], channels[1], target_size=(32, 32), downsample=False)
        self.stage2 = MeanFlowStage(channels[1], channels[2], target_size=(32, 32), downsample=True,
                                     use_learnable_downsample=not use_fixed_downsample)
        self.stage3 = MeanFlowStage(channels[2], channels[3], target_size=(16, 16), downsample=True,
                                     use_learnable_downsample=not use_fixed_downsample)

        self.stage4 = _TwoStepStage4Internal(in_channels=channels[3], out_channels=channels[4])

        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.linear = nn.Linear(channels[4], num_classes)

    def forward(self, x):

        x = self.conv1(x)
        x = self.bn1(x)
        x = F.relu(x)

        x = self.stage1(x)
        x = self.stage2(x)
        x_stage3 = self.stage3(x)

        x = self.stage4(x_stage3)

        x = self.avgpool(x)
        x = x.view(x.size(0), -1)
        x = self.linear(x)

        return x

pass

class LabelSmoothingCrossEntropy(nn.Module):

    def __init__(self, smoothing=0.1):
        super().__init__()
        self.smoothing = smoothing

    def forward(self, pred, target):
        n_classes = pred.size(1)

        one_hot = F.one_hot(target, n_classes).float()
        smoothed = one_hot * (1 - self.smoothing) + self.smoothing / n_classes

        log_probs = F.log_softmax(pred, dim=1)
        loss = -(smoothed * log_probs).sum(dim=1).mean()

        return loss

class Bottleneck(nn.Module):

    expansion = 4

    def __init__(self, in_planes, planes, stride=1):
        super(Bottleneck, self).__init__()

        self.bn1 = nn.BatchNorm2d(in_planes)
        self.conv1 = nn.Conv2d(in_planes, planes, kernel_size=1, bias=False)

        self.bn2 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=stride, padding=1, bias=False)

        self.bn3 = nn.BatchNorm2d(planes)
        self.conv3 = nn.Conv2d(planes, self.expansion * planes, kernel_size=1, bias=False)

        if stride != 1 or in_planes != self.expansion * planes:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_planes, self.expansion * planes, kernel_size=1, stride=stride, bias=False)
            )

    def forward(self, x):
        out = F.relu(self.bn1(x))
        shortcut = self.shortcut(out) if hasattr(self, 'shortcut') else x

        out = self.conv1(out)
        out = F.relu(self.bn2(out))
        out = self.conv2(out)
        out = F.relu(self.bn3(out))
        out = self.conv3(out)

        out += shortcut
        return out

def make_resnet_layer(block, in_planes, planes, num_blocks, stride):

    strides = [stride] + [1] * (num_blocks - 1)
    layers = []
    current_in_planes = in_planes

    for s in strides:
        layers.append(block(current_in_planes, planes, s))
        current_in_planes = planes * block.expansion

    return nn.Sequential(*layers)

class HybridMeanFlowResNet50_Stage4(nn.Module):

    def __init__(self, meanflow_model, num_blocks_layer4=3):
        super().__init__()

        self.conv1 = meanflow_model.conv1
        self.bn1 = meanflow_model.bn1
        self.stage1 = meanflow_model.stage1
        self.stage2 = meanflow_model.stage2
        self.stage3 = meanflow_model.stage3
        self.arch = 'resnet50'

        in_planes = 1024
        planes = 512
        out_planes = 2048
        pass

        self.layer4 = make_resnet_layer(
            Bottleneck,
            in_planes=in_planes,
            planes=planes,
            num_blocks=num_blocks_layer4,
            stride=2
        )
        self.out_planes = out_planes

        self.avgpool = meanflow_model.avgpool
        self.linear = meanflow_model.linear

    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = F.relu(x)

        x = self.stage1(x)
        x = self.stage2(x)
        x = self.stage3(x)
        x = self.layer4(x)

        x = self.avgpool(x)
        x = x.view(x.size(0), -1)
        x = self.linear(x)

        return x

def load_and_replace_stage4(meanflow_model_path, freeze_other_stages=True, train_classifier=True):

    pass
    pass
    pass

    pass
    pass

    if not os.path.exists(meanflow_model_path):
        pass
        pass

        possible_dirs = [
            './checkpoints_meanflow_trained',
            './checkpoints_meanflow_cifar10_resnet50'
        ]

        for dir_path in possible_dirs:
            if os.path.exists(dir_path):
                files = [f for f in os.listdir(dir_path) if f.endswith('.pth')]
                if files:
                    pass
                    for f in files[:5]:
                        pass
                    if len(files) > 5:
                        pass

        return None

    pass

    try:
        checkpoint = torch.load(meanflow_model_path, map_location='cpu', weights_only=False)
        pass
    except Exception as e:
        pass
        import traceback
        traceback.print_exc()
        return None

    pass
    num_classes = checkpoint.get('num_classes', 10)

    state_dict = checkpoint.get('model_state_dict', checkpoint)

    has_learnable_downsample = any('downsample_layer.weight' in k for k in state_dict.keys())
    use_fixed_downsample = not has_learnable_downsample

    pass
    pass
    pass
    pass
    pass

    pass

    try:

        pass
        meanflow_model = FourStageMeanFlowPipeline(
            num_classes=num_classes,
            use_fixed_downsample=use_fixed_downsample
        )
        pass

        pass
        pass

        model_state = meanflow_model.state_dict()

        stage1_key = None
        for key in model_state.keys():
            if 'stage1' in key and 'weight' in key and 'bn' not in key:
                stage1_key = key
                break

        if stage1_key:
            stage1_shape = model_state[stage1_key].shape
            pass
            pass

            out_channels = stage1_shape[0] if len(stage1_shape) > 0 else None

            if out_channels == 64:
                pass
                pass
                pass
                pass
                pass
                pass
                pass
                return None
            elif out_channels == 256:
                pass
            else:
                pass
        else:
            pass
            pass

        pass
        meanflow_model.eval()
        with torch.no_grad():
            test_input = torch.randn(1, 3, 32, 32)
            x = meanflow_model.conv1(test_input)
            x = meanflow_model.bn1(x)
            x = F.relu(x)
            x = meanflow_model.stage1(x)
            actual_stage1_out = x.shape[1]
            x = meanflow_model.stage2(x)
            actual_stage2_out = x.shape[1]
            x = meanflow_model.stage3(x)
            actual_stage3_out = x.shape[1]

        pass
        pass
        pass

        expected_channels = {
            'stage1': 256,
            'stage2': 512,
            'stage3': 1024
        }

        if actual_stage1_out != expected_channels['stage1'] or \
           actual_stage2_out != expected_channels['stage2'] or \
           actual_stage3_out != expected_channels['stage3']:
            pass
            pass
            pass
            pass
            pass
            pass
            return None
        else:
            pass
    except Exception as e:
        pass
        import traceback
        traceback.print_exc()
        return None

    pass
    try:

        model_dict = meanflow_model.state_dict()

        matched_dict = {}
        size_mismatch = []

        for k, v in state_dict.items():
            if k in model_dict:
                if model_dict[k].shape == v.shape:
                    matched_dict[k] = v
                else:
                    size_mismatch.append((k, v.shape, model_dict[k].shape))

        model_dict.update(matched_dict)
        meanflow_model.load_state_dict(model_dict, strict=False)

        loaded_keys = set(matched_dict.keys())
        all_keys = set(model_dict.keys())
        missing_keys = all_keys - loaded_keys

        pass

        if size_mismatch:
            pass
            for k, ckpt_shape, model_shape in size_mismatch[:3]:
                pass
                pass
            if len(size_mismatch) > 3:
                pass

            stage4_mismatch = [k for k, _, _ in size_mismatch if 'stage4' in k and 'conv' in k]
            if stage4_mismatch:
                pass

        if missing_keys:
            missing_count = len(missing_keys)
            pass

    except Exception as e:
        pass
        pass

    pass
    hybrid_model = HybridMeanFlowResNet50_Stage4(
        meanflow_model,
        num_blocks_layer4=3
    )
    pass

    total_params = sum(p.numel() for p in hybrid_model.parameters())
    layer4_params = sum(p.numel() for p in hybrid_model.layer4.parameters())

    pass
    pass
    pass

    if freeze_other_stages:
        pass

        for param in hybrid_model.conv1.parameters():
            param.requires_grad = False
        for param in hybrid_model.bn1.parameters():
            param.requires_grad = False
        for param in hybrid_model.stage1.parameters():
            param.requires_grad = False
        for param in hybrid_model.stage2.parameters():
            param.requires_grad = False
        for param in hybrid_model.stage3.parameters():
            param.requires_grad = False

        for param in hybrid_model.layer4.parameters():
            param.requires_grad = True

        if train_classifier:
            for param in hybrid_model.linear.parameters():
                param.requires_grad = True
        else:
            for param in hybrid_model.linear.parameters():
                param.requires_grad = False

        total_requires_grad = sum(p.numel() for p in hybrid_model.parameters() if p.requires_grad)
        frozen_params = total_params - total_requires_grad

        pass
        pass
        pass
        pass

        pass
        pass
        pass
        pass
        pass

        pass
        pass
        pass
        pass
        pass
        pass
    else:
        pass

    pass
    hybrid_model.eval()
    test_input = torch.randn(2, 3, 32, 32)

    try:
        with torch.no_grad():
            output = hybrid_model(test_input)
        pass
    except Exception as e:
        pass
        return None

    pass
    pass
    pass

    return hybrid_model

def train_hybrid_model(model, train_loader, test_loader, device, args):

    pass
    pass
    pass

    model = model.to(device)

    if args.use_label_smoothing:
        criterion = LabelSmoothingCrossEntropy(smoothing=args.smoothing)
        pass
    else:
        criterion = nn.CrossEntropyLoss()
        pass

    optimizer_params = []

    for param in model.layer4.parameters():
        if param.requires_grad:
            optimizer_params.append(param)

    if args.train_classifier:
        for param in model.linear.parameters():
            if param.requires_grad:
                optimizer_params.append(param)

    if args.optimizer == 'adamw':
        optimizer = optim.AdamW(
            optimizer_params,
            lr=args.lr,
            weight_decay=args.weight_decay
        )
        pass
    else:
        optimizer = optim.SGD(
            optimizer_params,
            lr=args.lr,
            momentum=0.9,
            weight_decay=args.weight_decay
        )
        pass

    scheduler = optim.lr_scheduler.CosineAnnealingLR(
        optimizer,
        T_max=args.epochs,
        eta_min=args.min_lr
    )
    pass

    pass
    pass
    pass
    pass
    pass

    layer4_params = sum(p.numel() for p in model.layer4.parameters() if p.requires_grad)
    pass
    pass
    if args.train_classifier:
        linear_params = sum(p.numel() for p in model.linear.parameters() if p.requires_grad)
        pass

    best_acc = 0.0
    best_epoch = 0

    for epoch in range(args.epochs):

        model.train()
        train_loss = 0.0
        train_correct = 0
        train_total = 0

        pbar = tqdm(train_loader, desc=f'Epoch {epoch+1}/{args.epochs} [Train]')
        for inputs, targets in pbar:
            inputs, targets = inputs.to(device), targets.to(device)

            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, targets)
            loss.backward()
            optimizer.step()

            train_loss += loss.item()
            _, predicted = outputs.max(1)
            train_total += targets.size(0)
            train_correct += predicted.eq(targets).sum().item()

            pbar.set_postfix({
                'loss': f'{train_loss/len(train_loader):.4f}',
                'acc': f'{100.*train_correct/train_total:.2f}%',
                'lr': f'{optimizer.param_groups[0]["lr"]:.6f}'
            })

        train_acc = 100. * train_correct / train_total
        train_loss = train_loss / len(train_loader)

        model.eval()
        test_loss = 0.0
        test_correct = 0
        test_total = 0

        with torch.no_grad():
            pbar = tqdm(test_loader, desc=f'Epoch {epoch+1}/{args.epochs} [Test]')
            for inputs, targets in pbar:
                inputs, targets = inputs.to(device), targets.to(device)
                outputs = model(inputs)
                loss = criterion(outputs, targets)

                test_loss += loss.item()
                _, predicted = outputs.max(1)
                test_total += targets.size(0)
                test_correct += predicted.eq(targets).sum().item()

                pbar.set_postfix({
                    'loss': f'{test_loss/len(test_loader):.4f}',
                    'acc': f'{100.*test_correct/test_total:.2f}%'
                })

        test_acc = 100. * test_correct / test_total
        test_loss = test_loss / len(test_loader)

        scheduler.step()
        current_lr = optimizer.param_groups[0]['lr']

        pass
        pass
        pass
        pass

        if test_acc > best_acc:
            best_acc = test_acc
            best_epoch = epoch + 1

            save_dict = {
                'epoch': epoch + 1,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
                'best_accuracy': best_acc,
                'train_accuracy': train_acc,
                'architecture': 'HybridMeanFlowResNet50_Stage4',
                'optimizer': args.optimizer,
                'use_label_smoothing': args.use_label_smoothing,
                'training_mode': 'Deep_Incubation_Enhanced_ResNet50',
                'args': vars(args)
            }

            torch.save(save_dict, args.checkpoint_path)
            pass

    pass
    pass
    pass
    pass
    pass
    pass

    return best_acc

def get_data_loaders(args):

    pass
    pass
    pass

    if args.use_enhanced_augmentation:
        pass
        transform_train = transforms.Compose([
            transforms.RandomCrop(32, padding=4),
            transforms.RandomHorizontalFlip(),
            transforms.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.4),
            transforms.ToTensor(),
            transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616)),
            transforms.RandomErasing(p=0.25)
        ])
    else:
        pass
        transform_train = transforms.Compose([
            transforms.RandomCrop(32, padding=4),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616))
        ])

    transform_test = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616))
    ])

    trainset = torchvision.datasets.CIFAR10(
        root=args.data_dir, train=True, download=True, transform=transform_train
    )
    train_loader = DataLoader(
        trainset, batch_size=args.batch_size, shuffle=True,
        num_workers=args.num_workers, pin_memory=True
    )

    testset = torchvision.datasets.CIFAR10(
        root=args.data_dir, train=False, download=True, transform=transform_test
    )
    test_loader = DataLoader(
        testset, batch_size=args.batch_size, shuffle=False,
        num_workers=args.num_workers, pin_memory=True
    )

    pass
    pass
    pass

    return train_loader, test_loader

def main():
    parser = argparse.ArgumentParser(

    )

    parser.add_argument('--meanflow-model', type=str,
                       default='./checkpoints_meanflow_trained/best_meanflow_pipeline_trained_res50.pth',
)
    parser.add_argument('--checkpoint-path', type=str,
                       default='./checkpoints_meanflow_cifar10_resnet50/hybrid_stage4_resnet50_enhanced_2steps.pth',
)

    parser.add_argument('--batch-size', type=int, default=128)
    parser.add_argument('--epochs', type=int, default=300)
    parser.add_argument('--optimizer', type=str, default='adamw', choices=['adamw', 'sgd'],
)
    parser.add_argument('--lr', type=float, default=0.001,
)
    parser.add_argument('--min-lr', type=float, default=1e-6)
    parser.add_argument('--weight-decay', type=float, default=0.05,
)

    parser.add_argument('--use-label-smoothing', action='store_true', default=True,
)
    parser.add_argument('--smoothing', type=float, default=0.1,
)
    parser.add_argument('--use-enhanced-augmentation', action='store_true', default=False,
)

    parser.add_argument('--data-dir', type=str, default='./data')
    parser.add_argument('--num-workers', type=int, default=4)
    parser.add_argument('--freeze-other', action='store_true', default=True,
)
    parser.add_argument('--train-classifier', action='store_true', default=True,
)
    parser.add_argument('--gpu', type=int, default=0)

    args = parser.parse_args()

    if args.optimizer == 'adamw' and args.lr == 0.001:
        pass
    elif args.optimizer == 'sgd' and args.lr == 0.001:
        args.lr = 0.01
        pass

    if args.optimizer == 'adamw' and args.weight_decay == 0.05:
        args.weight_decay = 0.01
        pass
    elif args.optimizer == 'sgd' and args.weight_decay == 0.05:
        args.weight_decay = 5e-4
        pass

    pass
    pass
    pass

    pass
    pass
    pass
    pass
    pass

    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass

    pass
    pass

    pass
    pass
    pass
    pass
    if torch.cuda.is_available():
        pass
        pass
        pass

        if args.gpu >= torch.cuda.device_count():
            pass
            pass
            pass
            args.gpu = 0
    pass

    device = torch.device(f'cuda:{args.gpu}' if torch.cuda.is_available() else 'cpu')
    pass

    hybrid_model = load_and_replace_stage4(
        args.meanflow_model,
        freeze_other_stages=args.freeze_other,
        train_classifier=args.train_classifier
    )

    if hybrid_model is None:
        pass
        return

    train_loader, test_loader = get_data_loaders(args)

    best_acc = train_hybrid_model(hybrid_model, train_loader, test_loader, device, args)

    pass
    pass

    pass
    pass
    pass
    pass

    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass

if __name__ == '__main__':
    main()
