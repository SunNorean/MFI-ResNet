
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
import torchvision.transforms as transforms
from torch.optim.lr_scheduler import CosineAnnealingLR
from tqdm import tqdm
import os
import argparse

class LabelSmoothingCrossEntropy(nn.Module):

    def __init__(self, smoothing=0.1):
        super().__init__()
        self.smoothing = smoothing

    def forward(self, pred, target):
        n_classes = pred.size(1)
        one_hot = F.one_hot(target, n_classes).float()
        smoothed = one_hot * (1 - self.smoothing) + self.smoothing / n_classes
        log_probs = F.log_softmax(pred, dim=1)
        loss = -(smoothed * log_probs).sum(dim=1).mean()
        return loss

class Bottleneck(nn.Module):

    expansion = 4

    def __init__(self, in_planes, planes, stride=1):
        super(Bottleneck, self).__init__()

        self.bn1 = nn.BatchNorm2d(in_planes)
        self.conv1 = nn.Conv2d(in_planes, planes, kernel_size=1, bias=False)

        self.bn2 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=stride, padding=1, bias=False)

        self.bn3 = nn.BatchNorm2d(planes)
        self.conv3 = nn.Conv2d(planes, self.expansion * planes, kernel_size=1, bias=False)

        if stride != 1 or in_planes != self.expansion * planes:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_planes, self.expansion * planes, kernel_size=1, stride=stride, bias=False)
            )

    def forward(self, x):
        out = F.relu(self.bn1(x))
        shortcut = self.shortcut(out) if hasattr(self, 'shortcut') else x

        out = self.conv1(out)
        out = F.relu(self.bn2(out))
        out = self.conv2(out)
        out = F.relu(self.bn3(out))
        out = self.conv3(out)

        out += shortcut
        return out

class TwoStepMeanFlowStage4_ResNet50(nn.Module):

    def __init__(self):
        super().__init__()

        self.dim_align_step1 = None
        self.meanflow_step1 = None

        self.dim_align_step2 = None
        self.meanflow_step2 = None

    def forward(self, x):

        B = x.shape[0]
        device = x.device

        r = torch.zeros(B, device=device)
        t = torch.ones(B, device=device)

        x_align_step1 = self.dim_align_step1(x)

        spatial_size_step1 = 8 * 8
        z_align_step1 = x_align_step1.permute(0, 2, 3, 1).reshape(
            B * spatial_size_step1, 2048
        )
        r_flat_step1 = r.repeat_interleave(spatial_size_step1)
        t_flat_step1 = t.repeat_interleave(spatial_size_step1)

        u_pred_step1 = self.meanflow_step1.forward_u(
            z_align_step1, r_flat_step1, t_flat_step1
        )
        z_mapped_step1 = z_align_step1 - u_pred_step1

        feat_step1 = z_mapped_step1.reshape(B, 8, 8, 2048).permute(0, 3, 1, 2)

        x_down_step2 = self.dim_align_step2(feat_step1)

        spatial_size_step2 = 4 * 4
        z_down_step2 = x_down_step2.permute(0, 2, 3, 1).reshape(
            B * spatial_size_step2, 2048
        )
        r_flat_step2 = r.repeat_interleave(spatial_size_step2)
        t_flat_step2 = t.repeat_interleave(spatial_size_step2)

        u_pred_step2 = self.meanflow_step2.forward_u(
            z_down_step2, r_flat_step2, t_flat_step2
        )
        z_mapped_step2 = z_down_step2 - u_pred_step2

        feat_step2 = z_mapped_step2.reshape(B, 4, 4, 2048).permute(0, 3, 1, 2)

        return feat_step2

def make_resnet_layer(block, in_planes, planes, num_blocks, stride, in_planes_override=None):

    strides = [stride] + [1]*(num_blocks-1)
    layers = []
    current_in_planes = in_planes_override if in_planes_override is not None else in_planes
    for s in strides:
        layers.append(block(current_in_planes, planes, s))
        current_in_planes = planes * block.expansion
    return nn.Sequential(*layers)

class HybridResNet50MeanFlow(nn.Module):

    def __init__(self, meanflow_stage4, num_classes=10):
        super().__init__()

        self.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(64)

        self.layer1 = make_resnet_layer(Bottleneck, 64, 64, 3, stride=1)
        self.layer2 = make_resnet_layer(Bottleneck, 256, 128, 4, stride=2)
        self.layer3 = make_resnet_layer(Bottleneck, 512, 256, 6, stride=2)

        self.stage4 = meanflow_stage4

        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.linear = nn.Linear(2048, num_classes)

    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = F.relu(x)

        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.stage4(x)

        x = self.avgpool(x)
        x = x.view(x.size(0), -1)
        x = self.linear(x)

        return x

def load_layer_from_hybrid_model(hybrid_checkpoint_path, layer_name):

    pass

    if not os.path.exists(hybrid_checkpoint_path):
        pass
        return None

    try:
        checkpoint = torch.load(hybrid_checkpoint_path, map_location='cpu', weights_only=False)
    except TypeError:
        checkpoint = torch.load(hybrid_checkpoint_path, map_location='cpu')

    if 'model_state_dict' in checkpoint:
        full_state = checkpoint['model_state_dict']
    else:
        full_state = checkpoint

    layer_state = {}
    prefix = f"{layer_name}."

    for key, value in full_state.items():
        if key.startswith(prefix):
            new_key = key[len(prefix):]
            layer_state[new_key] = value

    if layer_state:
        pass
    else:
        pass

    return layer_state

def load_twostep_meanflow_stage4_resnet50(checkpoint_path):

    pass
    pass

    if not os.path.exists(checkpoint_path):
        pass
        return None

    try:
        try:
            checkpoint = torch.load(checkpoint_path, map_location='cpu', weights_only=False)
        except TypeError:
            checkpoint = torch.load(checkpoint_path, map_location='cpu')

        if 'model_state_dict' in checkpoint:
            state_dict = checkpoint['model_state_dict']
        else:
            state_dict = checkpoint

        stage4_state = {}
        prefix = 'stage4.'

        for key, value in state_dict.items():
            if key.startswith(prefix):
                new_key = key[len(prefix):]
                stage4_state[new_key] = value

        if not stage4_state:
            pass
            return None

        pass

        class DimAlignModule_Step1(nn.Module):

            def __init__(self, in_channels=1024, out_channels=2048):
                super().__init__()
                self.out_channels = out_channels

                self.align_conv = nn.Conv2d(
                    in_channels=in_channels,
                    out_channels=out_channels,
                    kernel_size=1,
                    stride=1,
                    padding=0,
                    bias=False
                )
                self.bn = nn.BatchNorm2d(out_channels)

            def forward(self, x):
                x_align = self.align_conv(x)
                x_align = self.bn(x_align)
                x_align = F.relu(x_align)
                return x_align

        class DimAlignModule_Step2(nn.Module):

            def __init__(self, channels=2048):
                super().__init__()
                self.channels = channels

                self.downsample_conv = nn.Conv2d(
                    in_channels=channels,
                    out_channels=channels,
                    kernel_size=1,
                    stride=2,
                    padding=0,
                    bias=False
                )
                self.bn = nn.BatchNorm2d(channels)

            def forward(self, x):
                x_down = self.downsample_conv(x)
                x_down = self.bn(x_down)
                x_down = F.relu(x_down)
                return x_down

        class MeanFlowModule(nn.Module):

            def __init__(self, feature_dim):
                super().__init__()
                self.feature_dim = feature_dim

                self.time_emb = nn.Linear(2, 32)
                self.u_net = nn.Sequential(
                    nn.Linear(feature_dim + 32, 256),
                    nn.ReLU(),
                    nn.Linear(256, 256),
                    nn.ReLU(),
                    nn.Linear(256, feature_dim)
                )

            def forward_u(self, z, r, t):
                rt = torch.cat([r.unsqueeze(1), t.unsqueeze(1)], dim=1)
                rt_emb = self.time_emb(rt)
                z_rt = torch.cat([z, rt_emb], dim=1)
                u = self.u_net(z_rt)
                return u

        stage4_wrapper = TwoStepMeanFlowStage4_ResNet50()

        stage4_wrapper.dim_align_step1 = DimAlignModule_Step1(1024, 2048)
        stage4_wrapper.meanflow_step1 = MeanFlowModule(2048)

        stage4_wrapper.dim_align_step2 = DimAlignModule_Step2(2048)
        stage4_wrapper.meanflow_step2 = MeanFlowModule(2048)

        def load_module_weights(module, prefix, state_dict):

            module_state = {}
            skipped_keys = []

            for key, value in state_dict.items():
                if key.startswith(prefix):
                    new_key = key[len(prefix):]

                    if new_key in module.state_dict():
                        expected_shape = module.state_dict()[new_key].shape
                        actual_shape = value.shape

                        if expected_shape == actual_shape:
                            module_state[new_key] = value
                        else:
                            skipped_keys.append(f"{new_key}: {actual_shape} -> {expected_shape}")
                            pass

            if module_state:
                missing, unexpected = module.load_state_dict(module_state, strict=False)
                loaded_count = len(module_state)
                skipped_count = len(skipped_keys)

                if skipped_count > 0:
                    pass

                return loaded_count, len(missing), len(unexpected)
            return 0, 0, 0

        pass

        has_step_structure = any('step' in k.lower() for k in stage4_state.keys())

        if has_step_structure:

            pass
            n1, m1, u1 = load_module_weights(
                stage4_wrapper.dim_align_step1, 'dim_align_step1.', stage4_state
            )
            pass

            n2, m2, u2 = load_module_weights(
                stage4_wrapper.meanflow_step1, 'meanflow_step1.', stage4_state
            )
            pass

            n3, m3, u3 = load_module_weights(
                stage4_wrapper.dim_align_step2, 'dim_align_step2.', stage4_state
            )
            pass

            n4, m4, u4 = load_module_weights(
                stage4_wrapper.meanflow_step2, 'meanflow_step2.', stage4_state
            )
            pass
        else:

            pass
            pass

            n1, m1, u1 = load_module_weights(
                stage4_wrapper.dim_align_step1, 'dim_align.', stage4_state
            )
            pass

            n2, m2, u2 = load_module_weights(
                stage4_wrapper.meanflow_step1, 'meanflow.', stage4_state
            )
            pass

            pass
            pass

        total_params = sum(p.numel() for p in stage4_wrapper.parameters())
        pass

        if 'best_main_accuracy' in checkpoint:
            pass

        pass

        return stage4_wrapper

    except Exception as e:
        pass
        import traceback
        traceback.print_exc()
        return None

def assemble_hybrid_model_resnet50(stage_checkpoints, meanflow_stage4_path, base_model_path=None):

    pass
    pass
    pass

    pass
    meanflow_stage4 = load_twostep_meanflow_stage4_resnet50(meanflow_stage4_path)

    if meanflow_stage4 is None:
        pass
        return None

    pass
    model = HybridResNet50MeanFlow(meanflow_stage4, num_classes=10)
    pass

    pass

    layer_mapping = {
        'stage1': 'layer1',
        'stage2': 'layer2',
        'stage3': 'layer3'
    }

    success_count = 0
    for stage_key, layer_name in layer_mapping.items():
        checkpoint_path = stage_checkpoints[stage_key]
        layer_state = load_layer_from_hybrid_model(checkpoint_path, layer_name)

        if layer_state:
            layer_module = getattr(model, layer_name)

            current_state = layer_module.state_dict()
            matched_state = {}
            mismatched_keys = []

            for key, value in layer_state.items():
                if key in current_state:
                    if current_state[key].shape == value.shape:
                        matched_state[key] = value
                    else:
                        mismatched_keys.append((key, value.shape, current_state[key].shape))

            is_architecture_mismatch = False
            if mismatched_keys:

                first_mismatch = mismatched_keys[0]
                key, ckpt_shape, model_shape = first_mismatch

                if 'bn1' in key or 'conv1' in key:

                    if len(ckpt_shape) > 1 and len(model_shape) > 1:
                        ckpt_in_ch = ckpt_shape[1] if len(ckpt_shape) == 4 else ckpt_shape[0]
                        model_in_ch = model_shape[1] if len(model_shape) == 4 else model_shape[0]

                        if ckpt_in_ch == 64 and model_in_ch == 256:
                            pass
                            is_architecture_mismatch = True
                        elif ckpt_in_ch != model_in_ch:
                            pass
                            is_architecture_mismatch = True

            if matched_state and not is_architecture_mismatch:
                try:
                    missing, unexpected = layer_module.load_state_dict(matched_state, strict=False)

                    loaded_ratio = len(matched_state) / len(current_state)
                    if loaded_ratio > 0.5:
                        success_count += 1
                        pass
                    else:
                        pass
                except RuntimeError as e:

                    pass
                    pass
            else:
                if is_architecture_mismatch:
                    pass
                else:
                    pass

    pass

    if success_count == 0:
        pass
        pass
        pass
        pass
        pass
        pass
    elif success_count < 3:
        pass
    else:
        pass

    pass
    if base_model_path and os.path.exists(base_model_path):
        try:
            base_checkpoint = torch.load(base_model_path, map_location='cpu', weights_only=False)
        except TypeError:
            base_checkpoint = torch.load(base_model_path, map_location='cpu')

        if 'model_state_dict' in base_checkpoint:
            base_state = base_checkpoint['model_state_dict']
        else:
            base_state = base_checkpoint

        conv1_state = {}
        for key, value in base_state.items():
            if key.startswith('conv1.'):
                new_key = key[len('conv1.'):]
                conv1_state[new_key] = value
            elif key == 'conv1.weight' or (key == 'conv1' and len(value.shape) == 4):
                conv1_state['weight'] = value

        bn1_state = {}
        for key, value in base_state.items():
            if key.startswith('bn1.'):
                new_key = key[len('bn1.'):]
                bn1_state[new_key] = value

        if conv1_state:
            model.conv1.load_state_dict(conv1_state, strict=False)
            pass

        if bn1_state:
            model.bn1.load_state_dict(bn1_state, strict=False)
            pass
    else:
        pass

    pass

    pass
    try:
        model.eval()
        test_input = torch.randn(2, 3, 32, 32)
        with torch.no_grad():
            output = model(test_input)
        pass
    except Exception as e:
        pass
        import traceback
        traceback.print_exc()
        return None

    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass

    total_params = sum(p.numel() for p in model.parameters())
    pass

    pass
    pass
    pass

    return model

def train_one_epoch(model, train_loader, criterion, optimizer, device, epoch, total_epochs):

    model.train()
    running_loss = 0.0
    correct = 0
    total = 0

    pbar = tqdm(train_loader, desc=f'Epoch {epoch+1}/{total_epochs} [Train]')
    for inputs, targets in pbar:
        inputs, targets = inputs.to(device), targets.to(device)

        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, targets)
        loss.backward()
        optimizer.step()

        running_loss += loss.item()
        _, predicted = outputs.max(1)
        total += targets.size(0)
        correct += predicted.eq(targets).sum().item()

        pbar.set_postfix({
            'loss': f'{running_loss / (pbar.n + 1):.4f}',
            'acc': f'{100. * correct / total:.2f}%',
            'lr': f'{optimizer.param_groups[0]["lr"]:.6f}'
        })

    epoch_loss = running_loss / len(train_loader)
    epoch_acc = 100. * correct / total

    return epoch_loss, epoch_acc

def evaluate(model, test_loader, criterion, device):

    model.eval()
    running_loss = 0.0
    correct = 0
    total = 0

    with torch.no_grad():
        pbar = tqdm(test_loader, desc='[Eval]')
        for inputs, targets in pbar:
            inputs, targets = inputs.to(device), targets.to(device)

            outputs = model(inputs)
            loss = criterion(outputs, targets)

            running_loss += loss.item()
            _, predicted = outputs.max(1)
            total += targets.size(0)
            correct += predicted.eq(targets).sum().item()

            pbar.set_postfix({
                'loss': f'{running_loss / (pbar.n + 1):.4f}',
                'acc': f'{100. * correct / total:.2f}%'
            })

    test_loss = running_loss / len(test_loader)
    test_acc = 100. * correct / total

    return test_loss, test_acc

def finetune_model(model, train_loader, test_loader, device, args):

    pass
    pass
    pass

    if args.use_label_smoothing:
        criterion = LabelSmoothingCrossEntropy(smoothing=args.label_smoothing)
        pass
    else:
        criterion = nn.CrossEntropyLoss()
        pass

    if args.optimizer == 'adamw':
        optimizer = torch.optim.AdamW(
            model.parameters(),
            lr=args.lr,
            weight_decay=args.weight_decay,
            betas=(0.9, 0.999)
        )
        pass
    else:
        optimizer = torch.optim.SGD(
            model.parameters(),
            lr=args.lr,
            momentum=args.momentum,
            weight_decay=args.weight_decay
        )
        pass

    scheduler = CosineAnnealingLR(
        optimizer,
        T_max=args.epochs,
        eta_min=args.min_lr
    )
    pass

    pass
    pass
    pass
    pass

    best_acc = 0.0

    for epoch in range(args.epochs):

        train_loss, train_acc = train_one_epoch(
            model, train_loader, criterion, optimizer, device,
            epoch, args.epochs
        )

        test_loss, test_acc = evaluate(model, test_loader, criterion, device)

        scheduler.step()
        current_lr = optimizer.param_groups[0]['lr']

        pass
        pass
        pass
        pass

        if test_acc > best_acc:
            best_acc = test_acc

            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'best_accuracy': best_acc,
                'architecture': 'HybridResNet50TwoStepMeanFlow',
                'args': vars(args)
            }, os.path.join(args.save_dir, 'best_hybrid_resnet50_twostep_meanflow.pth'))
            pass

        pass

    pass

    return best_acc

def get_cifar10_loaders(batch_size=128, num_workers=4):

    pass

    transform_train = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616))
    ])

    transform_test = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616))
    ])

    trainset = torchvision.datasets.CIFAR10(
        root='./data', train=True, download=True, transform=transform_train
    )
    train_loader = torch.utils.data.DataLoader(
        trainset, batch_size=batch_size, shuffle=True,
        num_workers=num_workers, pin_memory=True
    )

    testset = torchvision.datasets.CIFAR10(
        root='./data', train=False, download=True, transform=transform_test
    )
    test_loader = torch.utils.data.DataLoader(
        testset, batch_size=batch_size, shuffle=False,
        num_workers=num_workers, pin_memory=True
    )

    pass
    pass

    return train_loader, test_loader

def main():
    parser = argparse.ArgumentParser(

    )

    parser.add_argument('--stage1-ckpt', type=str,
                        default='./checkpoints_meanflow_cifar10_resnet50/hybrid_stage1_resnet50_enhanced_2steps.pth',
)
    parser.add_argument('--stage2-ckpt', type=str,
                        default='./checkpoints_meanflow_cifar10_resnet50/best_model_layer2_res50_2steps.pth',
)
    parser.add_argument('--stage3-ckpt', type=str,
                        default='./checkpoints_meanflow_cifar10_resnet50/hybrid_stage3_resnet50_enhanced_2steps.pth',
)

    parser.add_argument('--meanflow-stage4', type=str,
                        default='./checkpoints_meanflow_trained/best_meanflow_pipeline_trained_2steps_res50.pth',
)

    parser.add_argument('--base-model', type=str,
                        default='./checkpoints_meanflow_trained/best_meanflow_pipeline_trained_res50.pth',
)

    parser.add_argument('--epochs', type=int, default=800)
    parser.add_argument('--batch-size', type=int, default=128)
    parser.add_argument('--optimizer', type=str, default='adamw', choices=['adamw', 'sgd'],
)
    parser.add_argument('--lr', type=float, default=0.01)
    parser.add_argument('--min-lr', type=float, default=1e-6)
    parser.add_argument('--momentum', type=float, default=0.9)
    parser.add_argument('--weight-decay', type=float, default=0.01)
    parser.add_argument('--use-label-smoothing', action='store_true', default=True,
)
    parser.add_argument('--label-smoothing', type=float, default=0.1)
    parser.add_argument('--save-dir', type=str, default='./checkpoints_assembled',
)
    parser.add_argument('--num-workers', type=int, default=4)
    parser.add_argument('--device', type=str, default='cuda')

    args = parser.parse_args()

    os.makedirs(args.save_dir, exist_ok=True)

    pass
    pass
    pass

    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass

    device = torch.device(args.device if torch.cuda.is_available() else 'cpu')
    pass

    stage_checkpoints = {
        'stage1': args.stage1_ckpt,
        'stage2': args.stage2_ckpt,
        'stage3': args.stage3_ckpt
    }

    model = assemble_hybrid_model_resnet50(
        stage_checkpoints,
        args.meanflow_stage4,
        args.base_model
    )

    if model is None:
        pass
        return

    model = model.to(device)

    train_loader, test_loader = get_cifar10_loaders(
        batch_size=args.batch_size,
        num_workers=args.num_workers
    )

    best_acc = finetune_model(
        model, train_loader, test_loader, device, args
    )

    pass
    pass
    pass
    pass

    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass

if __name__ == '__main__':
    main()
