
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader
import torchvision
import torchvision.transforms as transforms
import argparse
import os
from tqdm import tqdm

import importlib.util
_spec = importlib.util.spec_from_file_location(
    "merge_meanflow_pipeline_training",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "train_meanflow.py")
)
_module = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_module)
FourStageMeanFlowPipeline = _module.FourStageMeanFlowPipeline

class LabelSmoothingCrossEntropy(nn.Module):

    def __init__(self, smoothing=0.1):
        super().__init__()
        self.smoothing = smoothing
        self.confidence = 1.0 - smoothing

    def forward(self, pred, target):

        log_probs = F.log_softmax(pred, dim=-1)

        num_classes = pred.size(-1)
        smooth_target = torch.zeros_like(log_probs)
        smooth_target.fill_(self.smoothing / (num_classes - 1))
        smooth_target.scatter_(1, target.unsqueeze(1), self.confidence)

        loss = torch.sum(-smooth_target * log_probs, dim=-1)
        return loss.mean()

class TwoStepStage4(nn.Module):

    def __init__(self, in_channels=256):
        super().__init__()

        self.step1 = nn.Sequential(
            nn.Conv2d(in_channels, 512, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.Conv2d(512, 512, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True)
        )

        self.step2 = nn.Sequential(
            nn.Conv2d(512, 512, kernel_size=3, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.Conv2d(512, 512, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):

        x = self.step1(x)

        x = self.step2(x)

        return x

class PreActBottleneck(nn.Module):

    expansion = 4

    def __init__(self, in_planes, planes, stride=1):
        super(PreActBottleneck, self).__init__()

        self.bn1 = nn.BatchNorm2d(in_planes)
        self.conv1 = nn.Conv2d(in_planes, planes, kernel_size=1, bias=False)

        self.bn2 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=stride, padding=1, bias=False)

        self.bn3 = nn.BatchNorm2d(planes)
        self.conv3 = nn.Conv2d(planes, self.expansion * planes, kernel_size=1, bias=False)

        if stride != 1 or in_planes != self.expansion * planes:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_planes, self.expansion * planes, kernel_size=1, stride=stride, bias=False)
            )

    def forward(self, x):

        out = F.relu(self.bn1(x))
        shortcut = self.shortcut(out) if hasattr(self, 'shortcut') else x

        out = self.conv1(out)
        out = self.conv2(F.relu(self.bn2(out)))
        out = self.conv3(F.relu(self.bn3(out)))

        out += shortcut
        return out

def make_resnet50_layer(block, in_planes, planes, num_blocks, stride):

    strides = [stride] + [1] * (num_blocks - 1)
    layers = []
    current_in_planes = in_planes

    for s in strides:
        layers.append(block(current_in_planes, planes, s))
        current_in_planes = planes * block.expansion

    return nn.Sequential(*layers)

class HybridMeanFlowResNet50_Stage3(nn.Module):

    def __init__(self, meanflow_model, stage2_out_channels=128, stage4_expected_channels=256, num_blocks_layer3=6):
        super().__init__()

        self.conv1 = meanflow_model.conv1
        self.bn1 = meanflow_model.bn1
        self.stage1 = meanflow_model.stage1
        self.stage2 = meanflow_model.stage2

        self.layer3 = make_resnet50_layer(
            PreActBottleneck,
            in_planes=stage2_out_channels,
            planes=256,
            num_blocks=num_blocks_layer3,
            stride=2
        )

        self.channel_adapter = nn.Sequential(
            nn.Conv2d(1024, stage4_expected_channels, kernel_size=1, stride=1, bias=False),
            nn.BatchNorm2d(stage4_expected_channels),
            nn.ReLU(inplace=True)
        )

        self.stage4 = meanflow_model.stage4
        self.avgpool = meanflow_model.avgpool

        self.linear = meanflow_model.linear

    def forward(self, x):

        x = self.conv1(x)
        x = self.bn1(x)
        x = F.relu(x)

        x = self.stage1(x)

        x = self.stage2(x)

        x = self.layer3(x)

        x = self.channel_adapter(x)

        x = self.stage4(x)

        x = self.avgpool(x)
        x = x.view(x.size(0), -1)
        x = self.linear(x)

        return x

def load_and_replace_stage3_resnet50(meanflow_model_path, freeze_other_stages=True, train_classifier=False):

    pass
    pass
    pass

    pass
    if not os.path.exists(meanflow_model_path):
        pass
        return None

    checkpoint = torch.load(meanflow_model_path, map_location='cpu', weights_only=False)
    pass

    pass
    num_classes = checkpoint.get('num_classes', 10)

    state_dict = checkpoint.get('model_state_dict', checkpoint)

    has_learnable_downsample = any('downsample_layer.weight' in k for k in state_dict.keys())
    use_fixed_downsample = not has_learnable_downsample

    pass
    pass
    pass
    pass

    pass
    try:

        try:
            meanflow_model = FourStageMeanFlowPipeline(
                num_classes=num_classes,
                use_fixed_downsample=use_fixed_downsample,
                arch='resnet50'
            )
            pass
        except TypeError as te:

            if "unexpected keyword argument 'arch'" in str(te):
                pass
                meanflow_model = FourStageMeanFlowPipeline(
                    num_classes=num_classes,
                    use_fixed_downsample=use_fixed_downsample
                )
                pass
                pass
            else:
                raise
    except Exception as e:
        pass
        return None

    pass
    try:

        missing_keys, unexpected_keys = meanflow_model.load_state_dict(state_dict, strict=False)

        if missing_keys:
            pass
            for k in missing_keys[:5]:
                pass
            if len(missing_keys) > 5:
                pass

        if unexpected_keys:
            pass
            for k in unexpected_keys[:5]:
                pass
            if len(unexpected_keys) > 5:
                pass

        if not missing_keys and not unexpected_keys:
            pass
        else:
            pass

    except Exception as e:
        pass
        return None

    pass
    meanflow_model.eval()
    with torch.no_grad():
        test_input = torch.randn(1, 3, 32, 32)
        x = meanflow_model.conv1(test_input)
        x = meanflow_model.bn1(x)
        x = F.relu(x)
        x = meanflow_model.stage1(x)
        x = meanflow_model.stage2(x)
        stage2_out_channels = x.shape[1]
        x = meanflow_model.stage3(x)
        stage3_out_channels = x.shape[1]
    pass
    pass
    pass

    pass
    hybrid_model = HybridMeanFlowResNet50_Stage3(
        meanflow_model,
        stage2_out_channels=stage2_out_channels,
        stage4_expected_channels=stage3_out_channels,
        num_blocks_layer3=6
    )
    pass

    total_params = sum(p.numel() for p in hybrid_model.parameters())
    layer3_params = sum(p.numel() for p in hybrid_model.layer3.parameters())
    adapter_params = sum(p.numel() for p in hybrid_model.channel_adapter.parameters())
    stage4_params = sum(p.numel() for p in hybrid_model.stage4.parameters())

    num_classes_display = hybrid_model.linear.out_features

    pass
    pass
    pass
    pass
    pass
    pass

    if freeze_other_stages:
        pass

        for param in hybrid_model.conv1.parameters():
            param.requires_grad = False
        for param in hybrid_model.bn1.parameters():
            param.requires_grad = False

        for param in hybrid_model.stage1.parameters():
            param.requires_grad = False
        for param in hybrid_model.stage2.parameters():
            param.requires_grad = False

        for param in hybrid_model.layer3.parameters():
            param.requires_grad = True
        for param in hybrid_model.channel_adapter.parameters():
            param.requires_grad = True

        for param in hybrid_model.stage4.parameters():
            param.requires_grad = True

        if train_classifier:
            for param in hybrid_model.linear.parameters():
                param.requires_grad = True
        else:
            for param in hybrid_model.linear.parameters():
                param.requires_grad = False

        layer3_trainable = sum(p.numel() for p in hybrid_model.layer3.parameters() if p.requires_grad)
        adapter_trainable = sum(p.numel() for p in hybrid_model.channel_adapter.parameters() if p.requires_grad)
        linear_trainable = sum(p.numel() for p in hybrid_model.linear.parameters() if p.requires_grad)
        total_requires_grad = sum(p.numel() for p in hybrid_model.parameters() if p.requires_grad)
        frozen_params = total_params - total_requires_grad

        pass
        pass
        pass
        pass

        pass
        pass
        pass
        pass
        pass
        pass
        pass
        pass

        pass
        pass
        pass
        pass
        pass
        pass
        pass
    else:
        pass

    pass
    hybrid_model.eval()
    test_input = torch.randn(2, 3, 32, 32)

    try:
        with torch.no_grad():
            output = hybrid_model(test_input)
        pass
        pass
    except Exception as e:
        pass
        import traceback
        traceback.print_exc()
        return None

    pass
    pass
    pass

    return hybrid_model

def train_hybrid_model(model, train_loader, test_loader, device, args):

    pass
    pass
    pass

    model = model.to(device)

    if args.use_label_smoothing:
        criterion = LabelSmoothingCrossEntropy(smoothing=args.label_smoothing)
        pass
    else:
        criterion = nn.CrossEntropyLoss()
        pass

    optimizer_params = []

    for param in model.layer3.parameters():
        if param.requires_grad:
            optimizer_params.append(param)

    for param in model.channel_adapter.parameters():
        if param.requires_grad:
            optimizer_params.append(param)

    if args.train_classifier:
        for param in model.linear.parameters():
            if param.requires_grad:
                optimizer_params.append(param)

    if args.optimizer == 'adamw':
        optimizer = optim.AdamW(
            optimizer_params,
            lr=args.lr,
            weight_decay=args.weight_decay,
            betas=(0.9, 0.999)
        )
        pass
    else:
        optimizer = optim.SGD(
            optimizer_params,
            lr=args.lr,
            momentum=args.momentum,
            weight_decay=args.weight_decay
        )
        pass

    scheduler = optim.lr_scheduler.CosineAnnealingLR(
        optimizer,
        T_max=args.epochs,
        eta_min=args.min_lr
    )
    pass

    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass

    layer3_params = sum(p.numel() for p in model.layer3.parameters() if p.requires_grad)
    adapter_params = sum(p.numel() for p in model.channel_adapter.parameters() if p.requires_grad)
    linear_params = sum(p.numel() for p in model.linear.parameters() if p.requires_grad)
    stage4_params = sum(p.numel() for p in model.stage4.parameters())

    pass
    pass
    pass
    if args.train_classifier:
        pass
    pass

    best_acc = 0.0
    best_epoch = 0

    for epoch in range(args.epochs):

        model.train()
        train_loss = 0.0
        train_correct = 0
        train_total = 0

        pbar = tqdm(train_loader, desc=f'Epoch {epoch+1}/{args.epochs} [Train]')
        for inputs, targets in pbar:
            inputs, targets = inputs.to(device), targets.to(device)

            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, targets)
            loss.backward()
            optimizer.step()

            train_loss += loss.item()
            _, predicted = outputs.max(1)
            train_total += targets.size(0)
            train_correct += predicted.eq(targets).sum().item()

            pbar.set_postfix({
                'loss': f'{train_loss/len(train_loader):.4f}',
                'acc': f'{100.*train_correct/train_total:.2f}%',
                'lr': f'{optimizer.param_groups[0]["lr"]:.6f}'
            })

        train_acc = 100. * train_correct / train_total
        train_loss = train_loss / len(train_loader)

        model.eval()
        test_loss = 0.0
        test_correct = 0
        test_total = 0

        with torch.no_grad():
            pbar = tqdm(test_loader, desc=f'Epoch {epoch+1}/{args.epochs} [Test]')
            for inputs, targets in pbar:
                inputs, targets = inputs.to(device), targets.to(device)
                outputs = model(inputs)
                loss = criterion(outputs, targets)

                test_loss += loss.item()
                _, predicted = outputs.max(1)
                test_total += targets.size(0)
                test_correct += predicted.eq(targets).sum().item()

                pbar.set_postfix({
                    'loss': f'{test_loss/len(test_loader):.4f}',
                    'acc': f'{100.*test_correct/test_total:.2f}%'
                })

        test_acc = 100. * test_correct / test_total
        test_loss = test_loss / len(test_loader)

        scheduler.step()
        current_lr = optimizer.param_groups[0]['lr']

        pass
        pass
        pass
        pass

        if test_acc > best_acc:
            best_acc = test_acc
            best_epoch = epoch + 1

            save_dict = {
                'epoch': epoch + 1,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
                'best_accuracy': best_acc,
                'train_accuracy': train_acc,
                'architecture': 'HybridMeanFlowResNet50_Stage3_TwoStepStage4',
                'optimizer': args.optimizer,
                'lr_strategy': 'CosineAnnealingLR',
                'training_mode': 'Deep_Incubation_ResNet50_TwoStepStage4_Enhanced',
                'use_label_smoothing': args.use_label_smoothing,
                'label_smoothing': args.label_smoothing if args.use_label_smoothing else 0.0,
                'use_enhanced_augmentation': args.use_enhanced_augmentation,
                'note': 'Stage3: ResNet50 Bottleneck (expansion=4), Stage4: TwoStep structure, stage4 participates but not updated'
            }

            torch.save(save_dict, args.checkpoint_path)
            pass

    pass
    pass
    pass
    pass
    pass
    pass

    return best_acc

def get_data_loaders(args):

    pass
    pass
    pass

    transform_list_train = [
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
    ]

    if args.use_enhanced_augmentation:
        pass
        transform_list_train.append(
            transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.1)
        )
    else:
        pass

    transform_list_train.extend([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616))
    ])

    if args.use_enhanced_augmentation:
        transform_list_train.append(
            transforms.RandomErasing(p=0.5, scale=(0.02, 0.33), ratio=(0.3, 3.3))
        )

    transform_train = transforms.Compose(transform_list_train)

    transform_test = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616))
    ])

    trainset = torchvision.datasets.CIFAR10(
        root=args.data_dir, train=True, download=True, transform=transform_train
    )
    train_loader = DataLoader(
        trainset, batch_size=args.batch_size, shuffle=True,
        num_workers=args.num_workers, pin_memory=True
    )

    testset = torchvision.datasets.CIFAR10(
        root=args.data_dir, train=False, download=True, transform=transform_test
    )
    test_loader = DataLoader(
        testset, batch_size=args.batch_size, shuffle=False,
        num_workers=args.num_workers, pin_memory=True
    )

    pass
    pass
    pass

    return train_loader, test_loader

def main():
    parser = argparse.ArgumentParser(

    )

    parser.add_argument('--meanflow-model', type=str,
                       default='./checkpoints_meanflow_trained/best_meanflow_pipeline_trained_res50.pth',
)
    parser.add_argument('--checkpoint-path', type=str,
                       default='./checkpoints_meanflow_cifar10_resnet50/hybrid_stage3_resnet50_enhanced_2steps.pth',
)

    parser.add_argument('--optimizer', type=str, default='adamw', choices=['adamw', 'sgd'],
)
    parser.add_argument('--lr', type=float, default=0.001,
)
    parser.add_argument('--min-lr', type=float, default=1e-6,
)
    parser.add_argument('--momentum', type=float, default=0.9,
)
    parser.add_argument('--weight-decay', type=float, default=0.01,
)

    parser.add_argument('--use-label-smoothing', action='store_true', default=True,
)
    parser.add_argument('--label-smoothing', type=float, default=0.1,
)
    parser.add_argument('--use-enhanced-augmentation', action='store_true', default=False,
)

    parser.add_argument('--batch-size', type=int, default=128)
    parser.add_argument('--epochs', type=int, default=300)

    parser.add_argument('--data-dir', type=str, default='./data')
    parser.add_argument('--num-workers', type=int, default=4)

    parser.add_argument('--freeze-other', action='store_true', default=True,
)
    parser.add_argument('--train-classifier', action='store_true', default=False,
)
    parser.add_argument('--gpu', type=int, default=0)

    args = parser.parse_args()

    if torch.cuda.is_available():
        visible_gpu_count = torch.cuda.device_count()
        if visible_gpu_count == 0:
            pass
        elif args.gpu < 0 or args.gpu >= visible_gpu_count:
            pass
            args.gpu = 0
    else:
        pass

    if args.optimizer == 'adamw' and args.lr == 0.001:
        pass
    elif args.optimizer == 'sgd' and args.lr == 0.001:
        args.lr = 0.01
        pass

    if args.optimizer == 'adamw' and args.weight_decay == 0.01:
        pass
    elif args.optimizer == 'sgd' and args.weight_decay == 0.01:
        args.weight_decay = 5e-4
        pass

    pass
    pass
    pass

    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass

    device = torch.device(f'cuda:{args.gpu}' if torch.cuda.is_available() else 'cpu')
    pass

    hybrid_model = load_and_replace_stage3_resnet50(
        args.meanflow_model,
        freeze_other_stages=args.freeze_other,
        train_classifier=args.train_classifier
    )

    if hybrid_model is None:
        pass
        return

    train_loader, test_loader = get_data_loaders(args)

    best_acc = train_hybrid_model(hybrid_model, train_loader, test_loader, device, args)

    pass
    pass
    pass
    pass
    pass
    pass
    pass

    pass
    pass
    pass
    pass
    pass
    pass

    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass
    pass

if __name__ == '__main__':
    main()
